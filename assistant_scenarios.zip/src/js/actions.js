function addName(data, context) {
    addAction({
        type: "add_name",
        data: data
    }, context);
}