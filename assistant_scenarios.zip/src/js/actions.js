function addName(data, context) {
    addAction({
        type: "add_name",
        data: data
    }, context);
}

function restartGame(context) {
    addAction({
        type: "restart_game"
    }, context);
}

function pauseGame(context) {
    addAction({
        type: "pause_game"
    }, context);
}

function addNick(data, context) {
    addAction({
        type: "add_nickname",
        data: data
    }, context);
}